package com.ParkQuickBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkQuickBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
